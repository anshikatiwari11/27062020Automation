package pages.Truck;

public class SendQuote {

}
