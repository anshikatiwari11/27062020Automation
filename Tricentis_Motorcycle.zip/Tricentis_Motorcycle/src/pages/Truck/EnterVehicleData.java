package pages.Truck;

public class EnterVehicleData {

}
